package com.vacation.controller;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.vacation.model.*;
import com.vacation.dataaccess.*;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private LoginDataAccess loginDataaccess;

	public void init() {
		loginDataaccess = new LoginDataAccess();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		Login login = new Login();
		login.setUsername(username);
		login.setPassword(password);

		try {
			if (loginDataaccess.validate(login)) {
				
				if (SessionSingleton.getSessionObj().getIsManager())
					response.sendRedirect("managers_main_page.jsp");
				else
					response.sendRedirect("non_managers_main_page.jsp");
			} else {
				//HttpSession httpsession = request.getSession();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
