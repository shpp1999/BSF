package com.vacation.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SessionSingleton {
	 private static SessionSingleton SessionObj = new SessionSingleton();
	 private static Connection sessionConnection;
	 private String sessionOwner;
	 private boolean isManager = false;
	 private int sessionOwnerId;
	 
	 private SessionSingleton(){
		 try {
			sessionConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/EmployeesDB?allowPublicKeyRetrieval=true&useSSL=false", "root", "RootPass.2021");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			sessionConnection = null;
			e.printStackTrace();
		}
	 }  
	   
	 public static SessionSingleton getSessionObj(){  
	     return SessionObj;  
	 }
	 
	 public String getSessionOwner() {
	     return sessionOwner;
	 }
	 public void setSessionOwner(String username) {
	     this.sessionOwner = username;
	 }
	 public Connection getSessionConnection() {
	     return sessionConnection;
	 }
	 public void setIsManager(boolean isManager) {
	     this.isManager = isManager;
	 }
	 public boolean getIsManager() {
	     return isManager;
	 }
	 
	 public int getSessionOwnerId() {
	     return sessionOwnerId;
	 }
	 public void setSessionOwnerId(int id) {
	     this.sessionOwnerId = id;
	 }
	 
	 public boolean parseIntToBoolean(int flag)
	 {
		 if(flag == 0)
			 return false;
		 else
			 return true;
	 }
}