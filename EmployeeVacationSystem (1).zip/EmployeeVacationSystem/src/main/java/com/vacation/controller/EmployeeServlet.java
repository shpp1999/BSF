package com.vacation.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vacation.model.Employee;
import com.vacation.dataaccess.EmployeeDataAccess;

@WebServlet("/addAnEmployee")
public class EmployeeServlet extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private EmployeeDataAccess employeeDataaccess;

    public void init() {
        employeeDataaccess = new EmployeeDataAccess();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

    	int id = Integer.parseInt(request.getParameter("id"));
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        boolean isManager = Boolean.parseBoolean(request.getParameter("isManager"));
        int leaveBalance = Integer.parseInt(request.getParameter("leaveBalance"));

        Employee employee = new Employee();
        
        employee.setId(id);
        employee.setFirstName(firstName);
        employee.setLastName(lastName);
        employee.setUsername(username);
        employee.setPassword(password);
        employee.setIsManager(isManager);
        employee.setLeaveBalance(leaveBalance);

        try {
        	employeeDataaccess.addNewEmployee(employee);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        //response.sendRedirect("EmployeeDetails.jsp");
    }
    
}
