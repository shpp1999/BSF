package com.vacation.dataaccess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.vacation.controller.SessionSingleton;
import com.vacation.model.*;

public class LoginDataAccess {

	public boolean validate(Login login) throws ClassNotFoundException {
		boolean status = false;

		Class.forName("com.mysql.cj.jdbc.Driver");

        try (PreparedStatement preparedStatement = SessionSingleton.getSessionObj().getSessionConnection().prepareStatement("SELECT * FROM `EmployeesDB`.`Employee` WHERE UserName = ? AND Password = ? ")) {
			preparedStatement.setString(1, login.getUsername());
			preparedStatement.setString(2, login.getPassword());

			System.out.println(preparedStatement);
			ResultSet result = preparedStatement.executeQuery();

			status = result.next();
					
			if(status)
			{
				 SessionSingleton session = SessionSingleton.getSessionObj();
				 
				 session.setSessionOwner(result.getString("UserName"));
				 session.setSessionOwnerId(Integer.parseInt(result.getString("EmployeeID")));
			     session.setIsManager(session.parseIntToBoolean(Integer.parseInt(result.getString("IsManager"))));   
			}

		} catch (SQLException e) {
		
			printSQLException(e);
		}
		return status;
	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}
}
